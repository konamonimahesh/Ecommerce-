package banking_System;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class RBI_Bank {
	public static void main(String[] args) {
		System.out.println("*****WelCome to National Banking System ****");
		System.out.println("\n");
		System.out.println("Do you to open an Account :   1. Yes    2. No");
		Scanner sc = new Scanner(System.in);
		String choice = sc.nextLine();
		if(choice.equalsIgnoreCase("Yes")) {
			OpenAccount obj = new OpenAccount();
			obj.createAccount();
		}
		if(choice.equalsIgnoreCase("Yes")) {
		BankAccount obj1 = new BankAccount();
			obj1.showMenu();
			
		}
		
	}

}
class OpenAccount{
	String name ;
	int accountNumber;
	String accountType;
	String dateOfBirth;
	String bank;
	
	void createAccount() {
		Scanner sc = new Scanner(System.in);
		System.out.println("In which bank do you want to open Account :  1.SBI  2.Andra Bank  3. HDFC bank");
		int choiceBank = sc.nextInt();
		if(choiceBank  == 1) {
			bank = "SBI";
		}
		if(choiceBank  == 2) {
			bank = "Andra Bank";
		}
		if(choiceBank  == 3) {
			bank = "HDFC Bank";
		}
		System.out.println("Please enter your Name");
		sc.nextLine();
		name = sc.nextLine();
	
		
		System.out.println("Please enter your Date of Birth");
		dateOfBirth = sc.nextLine();
		
		
		System.out.println("What type of Account do you want to Open :  1. Saving  2. Current");
		int choice = sc.nextInt();
		if(choice == 1) {
			accountType = "Saving";
		}
		if(choice == 2) {
			accountType = "Current";
		}
		
		System.out.println("Your Account has been opened with below Details");
		System.out.println("Bank : "+ bank);
		System.out.println("Name  : "+ name);
		System.out.println("Date of Birth : "+ dateOfBirth);
		System.out.println("Account Type  "+ accountType);
		System.out.println("Account Number :  "+ Math.random());
		System.out.println("\n");
	}
	
}
 class BankAccount{
	 int balance;
	 int  previousTranscation;
	 String customerName;
	 String customerID;
	 String accountType;
	 double totalInterest;
	 
	 void calculateInterest(double balance) {
		 System.out.println("What type of account you have ; 1. Saving  2. Current");
		 Scanner sc = new Scanner(System.in);
		 int choice = sc.nextInt();
		 
		 if(choice == 1) {
			 accountType = " Saving";
			 int rate = 5;
			 int time;
			 System.out.println("Enter year to calculate Interest");
			 time= sc.nextInt();
			 double finalAmount = balance*(1+ rate*time);
			 
			 totalInterest = finalAmount - balance;
			 System.out.println("Total interest earned is ; "+ totalInterest);
		 }
		 if(choice == 2) {
			 accountType = " Current";
			 int rate = 6;
			 int time, n;
			 System.out.println("Enter year to calculate interest");
			 time = sc.nextInt();
			 System.out.println("Enter the Frequency that interest  has been compound in a year");
			 n = sc.nextInt();
			 
			 double finalAmount = balance*(Math.pow((1+ rate/n),n*time));
			 
			 totalInterest = finalAmount - balance;
			 System.out.println("Total interest earned is : "+totalInterest);
			 sc.close();
		 }
	 }
	   void deposit(int amount ) {
		   if(amount != 0) {
			   balance = balance + amount;
			   System.out.println("balance after deposit : "+ balance);
			   previousTranscation = amount;
		   }
	   }
	   void withdraw(int amount ) {
		   if(amount != 0) {
			   balance = balance - amount;
			   System.out.println("balance after deposit : "+ balance);
			   previousTranscation =  - amount;
		   }
	   }
	   void getPreviousTranscation() {
		   FileOutputStream    fileout;
		   PrintStream    print;
		   
		   
		   try {
			   fileout = new FileOutputStream("C:/Users/konam/eclipse-workspace/Recipt.txt");
			   print = new PrintStream(fileout);
			   
			   if(previousTranscation > 0) {
				   
				   print.append("Deposited : "+previousTranscation);
				   System.out.println("Deposited"+previousTranscation);
			   }else if(previousTranscation < 0) {
				   print.append("Withdrawn: " +previousTranscation);
				   System.out.println("Withdrawn : "+ Math.abs(previousTranscation));
			   }else {
				   System.out.println("No Transtion occured ");
			   }
			   print.close();
		   } catch(Exception e ) {
			   System.err.println("Error in Printing the data "+ e);
		   }
	   }
	   
	   
	   void showMenu() {
		   char option = '\0';
		   Scanner s = new Scanner (System.in);
		   System.out.println(" Welcome to the menu");
		   System.out.println("\n");
		   System.out.println(" A.  Check Balance ");
		   System.out.println(" B. Deposit Amount ");
		   System.out.println(" C. WithDraw Amount ");
		   System.out.println(" D. See Previous Transcation");
		   System.out.println(" E. Calculate  Interest ");
		   System.out.println(" F. Exit");
		   
		   do {
			   System.out.println(" ----------");
			   System.out.println(" Enter the Option ");
			   System.out.println(" ----------");
			   option = s.next().charAt(0);
			   System.out.println("\n");
			   
			   
			   switch(option) {
			   case 'A' :
				   System.out.println(" ----------");
				   System.out.println("Balance = "+ balance);
				   System.out.println(" ----------");
				   System.out.println("\n");
				   break;
				   
				   
			   case 'B':
				   System.out.println(" ----------");
				   System.out.println(" Enter the amount to deposit");
				   int amount = s.nextInt();
				   deposit(amount);
				   System.out.println("\n");
				   break;
				   
				   
			   case 'C':
				   System.out.println(" ----------");
				   System.out.println(" Enter the amount to withdraw");
				   int amount1 = s.nextInt();
				   withdraw(amount1);
				   System.out.println("\n");
				   break;
				   
			   case 'D':
				   System.out.println(" ----------");
				   getPreviousTranscation();
				   System.out.println("\n");
				   break;
				   
			   case 'E':
				   System.out.println(" ----------");
				   calculateInterest(balance);
				   System.out.println("\n");
				   break;
				   
				   
			   case 'F':
				   System.out.println(" ----------");
				   break;
				   
				   default:
					   System.out.println("Enter Invalid option.  Please enter Again");
					   break;
			   
			   }
		   }
			   while(option !='F');
			   System.out.println("Thank you using our service");
			   s.close();
			   
			   
		   
		   
	   }
	   
	 
	 
	 
 }
