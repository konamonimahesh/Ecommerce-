package userDetails;

public class Admin {

	public void setUserId(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	public void setPassword(String nextLine) {
		// TODO Auto-generated method stub
		
	}

	public boolean verifyUser() {
		// TODO Auto-generated method stub
		return true;
	}

}
