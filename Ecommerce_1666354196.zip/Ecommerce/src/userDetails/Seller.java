package userDetails;

import orderDetails.*;
import productDetails.Product;

public class Seller extends User{
	private Product [] productsListed;
	
	@Override
	public Boolean verifyUser() {
		return true;
	}
	public Product[] getProductsListed() {
		return productsListed;
	}
	public void setProductsListed(Product[] productsListed) {
		this.productsListed = productsListed;
	}
	public Cart getCart() {
	
		return null;
	}
	public void setCart(Cart cart) {
		
		
	}
	

}
