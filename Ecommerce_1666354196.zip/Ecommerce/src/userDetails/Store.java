package userDetails;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;


import orderDetails.Cart;
import orderDetails.Order;
import productDetails.Catalogue;
import productDetails.Product;


public class Store {
	public static void main(String[] args) {
		System.out.println("Welcome to the ecommerce store!");
		System.out.println("Which user are you? 1. Customer 2. Seller 3. Admin");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		String typeOfUser;
		if (choice == 1) {
			typeOfUser = "Customer";
			Customer current = new Customer();
			System.out.println("What is your userId?");
			sc.nextLine();
			current.setUserId(sc.nextLine());
			System.out.println("What is your passWord?");
			sc.nextLine();
			current.setPassword(sc.nextLine());
			if (current.verifyUser() == true) {
				System.out.println("User verified!");
				while (true) {

					System.out.println("Do you want to- 1. View products 2. View Cart 3. Contact Us 4. Exit");
					choice = sc.nextInt();
					if (choice == 1) {
						System.out.println("Choose Category");
						
						Catalogue catalogue = new Catalogue();
						Product[] allProducts = catalogue.getListofAllProducts();
						System.out.println("1.Laptops  2.Smart TV's  3.Mobiles ");
						sc.nextLine();
						int chooseCategory = sc.nextInt();
						String choose="  ";
						if(chooseCategory == 1) {
							choose = "Laptop";
						}
						else if (chooseCategory == 2) {
							choose = "Smart TV";
							
						}
						else if(chooseCategory==3) {
							choose = "Mobile";
						}																						
						for (int i = 0; i < allProducts.length; i++) {
							if (allProducts[i].getCategory().getCategoryName() == choose) 


							System.out.println(allProducts[i].getProductId() + " " + allProducts[i].getProductName()
								+ " " + allProducts[i].getCost());
							
						
						}
						System.out.println("Do you want to add any product to the cart? Y/N");
						sc.nextLine();
						String addToCart = sc.nextLine();
						if (addToCart.equals("Y")) {
							System.out.println("Input the product id of the product which you want to add to cart.");
							String productId = sc.nextLine();
							Product[] cartProducts = new Product[1];
							for (int i = 0; i < allProducts.length; i++) {
								if (allProducts[i].getProductId().equals(productId))
									cartProducts[0] = allProducts[i];
							}
						

							Cart cart = new Cart();
							cart.setCartId("1");
							cart.setListOfProducts(cartProducts);
							current.setCart(cart);
							System.out.println("The product is successfully added to the cart");
						}
						
						
					} else if (choice == 2) {
						Product[] cartProducts = current.getCart().getListOfProducts();
						System.out.println(current.getCart().getCartId());
						for (int i = 0; i < cartProducts.length; i++) {
							System.out.println(cartProducts[i].getProductId() + " " + cartProducts[i].getProductName()
									+ " " + cartProducts[i].getCost());
						}
						System.out.println("Do you want to checkout? Y/N");
						sc.nextLine();
						String checkout = sc.nextLine();
						if (checkout.equals("Y"))
							if (checkout.equals("Y"))
								if (current.getCart().checkOut()) {
									// Create an order object and assign this user to the order with an order id
									Order ordercheck = new Order();
									ordercheck.setUser(current);
									ordercheck.setOrderId("1");
									System.out.println("Your order id is " + ordercheck.getOrderId() + " for the user id "
											+ ordercheck.getUser().getUserId() + "is Successfully placed");
									String CustomerId = ordercheck.getUser().getUserId();
									System.out.println("Generating the  recipt");
									File f1=new File(CustomerId+".txt");
						try {
										BufferedWriter bw=new BufferedWriter(new FileWriter(f1,true));
										bw.write("Your Order ID is "+ ordercheck.getOrderId());
										bw.newLine();
										bw.write("For the user "+ ordercheck.getUser().getUserId());
										bw.write(" Thank you");
										System.out.println("Recipt Generated");
										bw.close();
									
									} catch (Exception e) {
										System.out.println("Problem while Creating Recipt");
										e.printStackTrace();
									}
									
								}

									
																
								
								System.out.println("Your order is placed successfully");

					} else if (choice == 3) {
						System.out.println("To contact us, please email on store@ecommerce.com");
					} else if (choice == 4)
						break;
					else
						System.out.println("Invalid choice, please try again.");

				}
			}
		} else if (choice == 2) {
			typeOfUser = "Seller";
		
		Seller current = new Seller();
		System.out.println("What is your userId?");
		sc.nextLine();
		current.setUserId(sc.nextLine());
		System.out.println("What is your passWord?");
		sc.nextLine();
		current.setPassword(sc.nextLine());
		
		if (current.verifyUser() == true) {
			System.out.println("User verified!");
			
			while(true) {
				System.out.println("Do you want to- 1. View products 2. Add Product 4. Exit");
				choice = sc.nextInt();
				if (choice == 1) {
					
					Catalogue catalogue = new Catalogue();
					Product[] allProducts = catalogue.getListofAllProducts();
					for (int i = 0; i < allProducts.length; i++) {
						System.out.println(allProducts[i].getProductId() + " " + allProducts[i].getProductName()
								+ " " + allProducts[i].getCost());
					}
					
				}else if (choice == 2) {
					System.out.println("Select product id which do you to add any product ");
					
					String getId = sc.nextLine();
					sc.nextInt();
				Catalogue catalgoueSeller = new Catalogue();
				Product[] sellerProduct = catalgoueSeller.getSellerProducts();
				Product[] sellerAddProduct = new Product[1];
				for(int i=0; i< sellerAddProduct.length;i++) {
					if(sellerProduct[i].getProductId().equals(getId)) {
						sellerAddProduct[0] = sellerProduct[i];
					}
					current.setProductsListed(sellerAddProduct);
					System.out.println("Product Added Successfully ");
				}
			}else if (choice == 3) {
				System.out.println("To contact us, please email on store@ecommerce.com");
			} else if (choice == 4)
				break;
			else
				System.out.println("Invalid choice, please try again.");
					
			}
		}
	
		}else if (choice == 3) 
			typeOfUser = "Admin";
		Admin current1 = new Admin();
		System.out.println("What is your userId?");
		sc.nextLine();
		current1.setUserId(sc.nextLine());
		System.out.println("What is your passWord?");
		sc.nextLine();
		current1.setPassword(sc.nextLine());
		if (current1.verifyUser() == true) {
			System.out.println("User verified!");
		
		while (true) {
			System.out.println("Do You Want To 1.View all Products");
			int ChoiceAdmin = sc.nextInt();
			if (ChoiceAdmin == 1) {
				Catalogue catalogue2 = new Catalogue();
				Product[] Show = catalogue2.getListofAllProducts();
				for (int i = 0; i < Show.length; i++) {
					System.out.println(
							"" + Show[i].getProductId() + " " + Show[i].getProductName() + " " + Show[i].getCost());
				}
				System.out.println("Seller Products");
				Product[] Show2 = catalogue2.getSellerProducts();
				for (int i = 0; i < Show2.length; i++) {
					System.out.println("" + Show2[i].getProductId() + " " + Show2[i].getProductName() + " "
							+ Show2[i].getCost());
				}
			}
		
		else
			System.out.println("Invalid input. Try again");
	      }
		}
}	
	
}