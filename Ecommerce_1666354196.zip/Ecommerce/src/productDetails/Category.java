package productDetails;



public class Category {
	private String categoryName;
	private Category[] subCategories;

	
	
	public Category(String categoryName, Category[] subCategories) {
		super();
		this.categoryName = categoryName;
		this.subCategories = subCategories;
	}

	public Category() {
		
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Category[] getSubCategories() {
		return subCategories;
	}
}