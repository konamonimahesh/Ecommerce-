package productDetails;



public class Catalogue {
	private Product[] listofAllProducts;
	Category category = new Category();
	Category category1= new Category();
	Category category2= new Category();
	
	

	public Product[] getListofAllProducts() {
		 category.setCategoryName("Laptop");
		 category1.setCategoryName("Smart TV");
		 category2.setCategoryName("Mobile");
		 
		Product product1 = new Product();
		product1.setProductId("1");
		product1.setProductName("Lenovo thinkPad");
		product1.setCost("40000");
		product1 .setCategory(category);
		Product product2 = new Product();
		product2.setProductId("2");
		product2.setProductName("HP 15s");
		product2.setCost("38000");
		product2 .setCategory(category);
		
		Product product3 = new Product();
		product3.setProductId("3");
		product3.setProductName("Acer Aspire 3");
		product3.setCost("47000");
		product3 .setCategory(category);
		
		Product product4 = new Product();
		product4.setProductId("4");
		product4.setProductName("Vivo Chromebook ");
		product4.setCost("60000");
		product4 .setCategory(category);
		
		Product product5 = new Product();
		product5.setProductId("5");
		product5.setProductName("Redmi 9s Mobile ");
		product5.setCost("20000");
		product5 .setCategory(category2);
		
		Product product6 = new Product();
		product6.setProductId("6");
		product6.setProductName("Samsung Galaxy Mobile ");
		product6.setCost("23000");
		product6 .setCategory(category2);
		

		Product product7 = new Product();
		product7.setProductId("7");
		product7.setProductName("Sony TV");
		product7.setCost("45000");
		product7 .setCategory(category1);
		

		Product product8 = new Product();
		product8.setProductId("8");
		product8.setProductName("MI TV");
		product8.setCost("45000");
		product8 .setCategory(category1);
		
		Product product9 = new Product();
		product9.setProductId("9");
		product9.setProductName("OPPO A76 Mobile");
		product9.setCost("45000");
		product9 .setCategory(category2);
		
		
		
		listofAllProducts = new Product[9];
		listofAllProducts[0] = product1;
		listofAllProducts[1] = product2;
		listofAllProducts[2] = product3;
		listofAllProducts[3] = product4;
		listofAllProducts[4] = product5;
		listofAllProducts[5] = product6;
		listofAllProducts[6] = product7;
		listofAllProducts[7] = product8;
		listofAllProducts[8] = product9;
		return listofAllProducts;
	}
	
	public Product[] getSellerProducts() {
		Product product1 = new Product();
		product1.setProductId("1");
		product1.setProductName("Micro Owen");
		product1.setCost("10000 RS");
		Product product2 = new Product();
		product2.setProductId("2");
		product2.setProductName("FRIDGE");
		product2.setCost("20000 RS");
		
		Product product3 = new Product();
		product3.setProductId("3");
		product3.setProductName("Washing Machine");
		product3.setCost("20000 RS");
		listofAllProducts = new Product[3];
		listofAllProducts[0] = product1;
		listofAllProducts[1] = product2;
		listofAllProducts[2] = product3;
		
		return listofAllProducts;
	}
	
	
	

	public void setListofAllProducts(Product[] listofAllProducts) {
		this.listofAllProducts = listofAllProducts;
	}



}
